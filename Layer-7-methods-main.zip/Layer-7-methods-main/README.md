# Layer 7 ddos methods
- Collecting by @zxcr9999
- Contact: @zxcr9999 (telegram)
